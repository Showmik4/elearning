<!-- footer start-->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 footer-copyright text-center">            
                <p><?php echo e(date('Y')); ?> © <?php echo e(@$setting->companyName); ?> | Designed & Developed by <a href="">Bkash</a></p>
            </div>
        </div>
    </div>
</footer>
<!-- footer end-->

<?php /**PATH C:\laragon\www\elearning\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>