
<?php $__env->startSection('title'); ?><?php echo e('Setting Edit'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('header.css'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main.content'); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-6">
                        <h3>Setting Edit</h3>
                    </div>
                    <div class="col-6">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('index')); ?>">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">Settings</li>
                            <li class="breadcrumb-item active">Setting</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <form class="form-wizard" action="<?php echo e(route('setting.update', $setting->settingId)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row ">
                                    <div class="col-md-8">
                                        <div class="mb-3">
                                            <label for="companyName">Company Name</label>
                                            <input class="form-control" id="companyName" name="companyName" type="text" placeholder="Company Name" value="<?php echo e(@$setting->companyName); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('companyName')); ?></b></span>
                                        </div>
                                        <div class="mb-3">
                                            <label for="email">Company Email</label>
                                            <input class="form-control" id="email" name="email" type="email" placeholder="Company Email" value="<?php echo e(@$setting->email); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('email')); ?></b></span>
                                        </div>
                                        <div class="mb-3">
                                            <label for="logo">Company Logo-1</label>
                                            <input class="form-control" id="logo" name="logo" type="file">
                                            <span class="text-danger"><b><?php echo e($errors->first('logo')); ?></b></span>
                                        </div>
                                        <?php if(isset($setting->logo)): ?>
                                        <div class="mb-3">
                                            <img height="100px" width="100px" src="<?php echo e(url(@$setting->logo)); ?>" alt="">
                                        </div>
                                        <?php endif; ?>
                                        <div class="mb-3">
                                            <label for="logoDark">Company Logo-2</label>
                                            <input class="form-control" id="logoDark" name="logoDark" type="file">
                                            <span class="text-danger"><b><?php echo e($errors->first('logoDark')); ?></b></span>
                                        </div>
                                        <?php if(isset($setting->logoDark)): ?>
                                            <div class="mb-3">
                                                <img height="100px" width="100px" src="<?php echo e(url(@$setting->logoDark)); ?>" alt="">
                                            </div>
                                        <?php endif; ?>
                                        <div class="mb-3">
                                            <label for="address">Company Address</label>
                                            <input class="form-control" id="address" name="address" type="text" placeholder="Company Address" value="<?php echo e(@$setting->address); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('address')); ?></b></span>
                                        </div>                                       
                                        <div class="mb-3">
                                            <label for="phone">Company Phone</label>
                                            <input class="form-control" id="phone" name="phone" type="text" placeholder="Company Phone" value="<?php echo e(@$setting->phone); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('phone')); ?></b></span>
                                        </div>    
                                        
                                        <div class="mb-3">
                                            <label for="phone">Twitter Link</label>
                                            <input class="form-control" id="phone" name="twitter_link" type="text" placeholder="Twitter Link" value="<?php echo e(@$setting->twitter_link); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('twitter_link')); ?></b></span>
                                        </div>  

                                        <div class="mb-3">
                                            <label for="phone">Facebook Link</label>
                                            <input class="form-control" id="phone" name="facebook_link" type="text" placeholder="Facebook Link" value="<?php echo e(@$setting->facebook_link); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('facebook_link')); ?></b></span>
                                        </div>  

                                        <div class="mb-3">
                                            <label for="phone">Instagram Link</label>
                                            <input class="form-control" id="phone" name="instagram_link" type="text" placeholder="Instagram Link" value="<?php echo e(@$setting->instagram_link); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('instagram_link')); ?></b></span>
                                        </div>  

                                        <div class="mb-3">
                                            <label for="phone">Linkedin Link</label>
                                            <input class="form-control" id="phone" name="linkedin_link" type="text" placeholder="Linkedin Link" value="<?php echo e(@$setting->linkedin_link); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('linkedin_link')); ?></b></span>
                                        </div>  

                                        <div class="mb-3">
                                            <label for="phone">Footer Text</label>
                                            <input class="form-control" id="phone" name="footer_text" type="text" placeholder="Footer_text" value="<?php echo e(@$setting->footer_text); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('footer_text')); ?></b></span>
                                        </div> 
                                        
                                        <div class="mb-3">
                                            <label for="google_map_link">Google Map Link</label>
                                            <input class="form-control" id="google_map_link" name="google_map_link" type="text" placeholder="Google Map Link" value="<?php echo e(@$setting->google_map_link); ?>" required>
                                            <span class="text-danger"><b><?php echo e($errors->first('google_map_link')); ?></b></span>
                                        </div> 

                                        <div class="mb-3">
                                            <label for="contact_page_banner_text">Contact Page Banner Text</label>
                                            <textarea class="form-control" id="contact_page_banner_text" name="contact_page_banner_text" type="text" placeholder="Contact Page Banner Text" value="" required><?php echo e(@$setting->contact_page_banner_text); ?></textarea>
                                            <span class="text-danger"><b><?php echo e($errors->first('contact_page_banner_text')); ?></b></span>
                                        </div> 

                                        <div class="mb-3">
                                            <label for="address">Trainer Page Banner Text</label>
                                            <textarea class="form-control" id="trainer_page_banner_text" name="trainer_page_banner_text" type="text" placeholder="Trainer Page Banner Text" value="" required><?php echo e(@$setting->trainer_page_banner_text); ?></textarea>
                                            <span class="text-danger"><b><?php echo e($errors->first('trainer_page_banner_text')); ?></b></span>
                                        </div> 

                                        <div class="mb-3">
                                            <label for="address">Course Page Banner Text</label>
                                            <textarea class="form-control" id="course_page_banner_text" name="course_page_banner_text" type="text" placeholder="Course Page Banner Text" value="" required><?php echo e(@$setting->course_page_banner_text); ?></textarea>
                                            <span class="text-danger"><b><?php echo e($errors->first('course_page_banner_text')); ?></b></span>
                                        </div> 
                                                                         
                                        <div class="text-end btn-mb">
                                            <button class="btn btn-secondary" type="button"><a class="text-white" href="<?php echo e(route('setting.show')); ?>">Cancel</a></button>
                                            <button class="btn btn-primary" type="submit">Update</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer.js'); ?>
    <script>
        $(document).ready( function () {
            // CKEDITOR.replace( 'contactText1');            
            // CKEDITOR.replace( 'footer_text');
            // CKEDITOR.replace( 'aboutTitle');
            // CKEDITOR.replace( 'aboutTop');
            // CKEDITOR.replace( 'aboutLeftText');
            // CKEDITOR.replace( 'aboutRightText');
            // CKEDITOR.replace( 'homeCategoryText');
            // CKEDITOR.replace( 'homeAboutUsText');
            // CKEDITOR.replace( 'newProductText');
            // CKEDITOR.replace( 'homeShowroomText');
            // CKEDITOR.replace( 'nav_banner_text');   
            // CKEDITOR.replace( 'about_page_md_message');
            CKEDITOR.replace( 'contact_page_banner_text');  
            CKEDITOR.replace( 'trainer_page_banner_text');  
            CKEDITOR.replace( 'course_page_banner_text');         
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elearning\resources\views/setting/edit.blade.php ENDPATH**/ ?>