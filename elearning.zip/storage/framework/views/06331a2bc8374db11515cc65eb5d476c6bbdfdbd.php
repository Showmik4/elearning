
<!doctype html>
<html lang="en">
<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <div class="container-fluid p-0">
        <div class="row m-0">
            <div class="col-12 p-0">
                <div class="login-card login-dark">
                    <div>
                        <div class="login-main">
                            <div>
                                <div class="card w-200">
                                    <div class="card-body  text-lg-center">
                                      <h1 class="card-title">Thank You</h1>
                                      <h5 class="card-text">You should receive a confirmation mail from QUCOSO client support within 2 days </h5>
                                      <h5 class="card-text">Please click the email to active your account</h5>          
                                    </div>
                                  </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\elearning\resources\views/auth/confirm_registration.blade.php ENDPATH**/ ?>