<header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="index.html" class="logo d-flex align-items-center me-auto">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1 class="sitename">Mentor</h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?php echo e(route('homepage')); ?>" class="active">Home<br></a></li>
          <li><a href="<?php echo e(route('aboutus')); ?>">About</a></li>
          <li><a href="<?php echo e(route('course')); ?>">Courses</a></li>
          <li><a href="<?php echo e(route('trainer')); ?>">Trainers</a></li>
          
          
          <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
          <?php if(auth()->guard()->guest()): ?>
          <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
          <?php endif; ?>
          <?php if(auth()->guard()->check()): ?>
          <li><a href="<?php echo e(route('index')); ?>">Dashboard</a></li>
          <?php endif; ?>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      

    </div>
  </header><?php /**PATH C:\laragon\www\elearning\resources\views/frontend/layouts/partials/navbar.blade.php ENDPATH**/ ?>