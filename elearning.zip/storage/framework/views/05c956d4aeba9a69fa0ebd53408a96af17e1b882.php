
<?php $__env->startSection('title'); ?>
    <?php echo e('Roles & Permission'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header.css'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main.content'); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-6">
                        <h3>Roles & Permissions</h3>
                    </div>
                    <div class="col-6">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('index')); ?>">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">Settings</li>
                            <li class="breadcrumb-item active">Roles & Permissions</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 mx-auto">
                    <div class="card border-top border-0 border-4 border-success">
                        <div class="card-body">
                            <form class="form-wizard" action="<?php echo e(route('userType.update', $userType->userTypeId)); ?>"
                                method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="mb-3">
                                            <label for="typeName">Role</label>
                                            <input class="form-control" id="typeName" name="typeName" type="text"
                                                placeholder="User Type Name" value="<?php echo e(@$userType->typeName); ?>" required>
                                            <span class="text-danger"> <b><?php echo e($errors->first('typeName')); ?></b></span>
                                        </div>
                                        <div class="text-start btn-mb">
                                            <button class="btn btn-secondary" type="button"><a class="text-white"
                                                    href="<?php echo e(route('userType.show')); ?>">Cancel</a></button>
                                            <button class="btn btn-primary" type="submit">Update</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
             
        <?php
        $prefixes = ['user','setting','userType','team','survey','kpi_type','kpi_subtype','kpi','trainer','category','course','homepage_settings','testimonial','about'
        ];
        ?>
        <div class="col-12 mx-auto">
            <div class="card border-top border-0 border-4 border-success">
                <div class="card-body p-5">
                    <div class="card-title d-flex align-items-center">
                        <h5 class="mb-0 text-primary">Role Permission</h5>
                    </div>
                    <hr />
                    <form action="<?php echo e(route('userType.role-update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="role_id" value="<?php echo e($userType->userTypeId); ?>">
                        <div class="row">
                            <?php $__currentLoopData = $prefixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prefix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h3><?php echo e(ucfirst($prefix)); ?> Permissions</h3>
                            <?php $__currentLoopData = $permissions->filter(function ($permission) use ($prefix) {
                            return preg_match("/^{$prefix}(\W|$)/", $permission->name);
                            }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-3">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend mx-4">
                                        <div class="input-group-text">
                                            <input id="permission_id_<?php echo e($permission->id); ?>" type="checkbox"
                                                name="permission_id[]" value="<?php echo e($permission->id); ?>" <?php if
                                                (in_array($permission->id,
                                            $rolePermission->pluck('permission_id')->toArray())) echo 'checked'; ?>
                                            aria-label="Checkbox for following text input">
                                        </div>
                                    </div>
                                    <label for="permission_id_<?php echo e($permission->id); ?>"><?php echo e(str_replace('_', ' ',\Illuminate\Support\Str::title($permission->name))); ?></label>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elearning\resources\views/userType/edit.blade.php ENDPATH**/ ?>