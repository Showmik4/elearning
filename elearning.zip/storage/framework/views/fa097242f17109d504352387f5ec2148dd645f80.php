
<?php $__env->startSection('title'); ?><?php echo e('Course'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('header.css'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main.content'); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-6">
                        <h3>Course</h3>
                    </div>
                    <div class="col-6">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item">Settings</li>
                            <li class="breadcrumb-item active">Course</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="row">
                <!-- Zero Configuration  Starts-->
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-end mb-3">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('course.create')): ?>
                                <a href="<?php echo e(route('course.create')); ?>" class="btn btn-md btn-info " ><i class="fa fa-plus"></i>Create New</a>
                                <?php endif; ?>
                               
                            </div>
                            <div class="table-responsive">
                                <table id="courseTable" class="table table-striped"></table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Zero Configuration  Ends-->
            </div>
        </div>
        <!-- Container-fluid Ends-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer.js'); ?>
    <script>
        $(document).ready(function () {
            $('#courseTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    "url": "<?php echo e(route('course.list')); ?>",
                    "type": "POST",
                    data: function (d) {
                        d._token = "<?php echo e(csrf_token()); ?>";
                    },
                },
                columns: [
                    {title: 'ID', data: 'id', name: 'id', className: "text-center", orderable: true, searchable: true},
                    {title: 'Title', data: 'title', name: 'title', className: "text-center", orderable: true, searchable: true},   
                    {title: 'category', data: 'category', name: 'category', className: "text-center", orderable: true, searchable: true},  
                    {title: 'trainer', data: 'trainer', name: 'trainer', className: "text-center", orderable: true, searchable: true},            
                    { 
                    title: 'Action', 
                    className: "text-center", 
                    data: function (data) {
                        let buttons = '';                       
                    
                        if (data.permissions.includes('course.edit')) {
                            buttons += '<a title="edit" class="btn btn-warning btn-sm" data-panel-id="' + data.id + '" onclick="editCourse(this)"><i class="fa fa-edit"></i></a>';
                        }
                        if (data.permissions.includes('course.delete')) {
                            buttons += ' <a title="delete" class="btn btn-danger btn-sm" data-panel-id="' + data.id + '" onclick="deleteCourse(this)"><i class="fa fa-trash"></i></a>';
                        }
                        return buttons || 'No Actions Available'; 
                    }, 
                    orderable: false, 
                    searchable: false
                 }
                ],              
                
            });
        });

        function editCourse(x) {
            let btn = $(x).data('panel-id');
            let url = '<?php echo e(route("course.edit", ":id")); ?>';
            window.location.href = url.replace(':id', btn);
        }

        function deleteCourse(x) {
            let id = $(x).data('panel-id');
            if (!confirm("Delete This Course")) {
                return false;
            }
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('course.delete')); ?>",
                cache: false,
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    'id': id
                },
                success: function (data) {
                    toastr.success('Course deleted successfully!');
                    $('#courseTable').DataTable().clear().draw();
                },
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elearning\resources\views/course/index.blade.php ENDPATH**/ ?>