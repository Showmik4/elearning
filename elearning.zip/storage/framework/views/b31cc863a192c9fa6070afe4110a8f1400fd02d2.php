

<?php $__env->startSection('title'); ?>
<?php echo e('Checkout'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend_main.content'); ?>
<main class="main">
    <!-- Page Title -->
    <div class="page-title" data-aos="fade">
      <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>Checkout</h1>
              <p class="mb-0">Complete your purchase securely.</p>
            </div>
          </div>
        </div>
      </div>
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">Checkout</li>
          </ol>
        </div>
      </nav>
    </div><!-- End Page Title -->

    <!-- Checkout Section -->
    <section id="checkout" class="checkout section">
      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row gy-4">

          <div class="col-lg-6">
            <h3>Billing Details</h3>
            <form action="" method="post" class="php-checkout-form">
              <?php echo csrf_field(); ?>
              <div class="row gy-4">
                <div class="col-md-6">
                  <input type="text" name="name" class="form-control" placeholder="Full Name" required>
                </div>
                <div class="col-md-6">
                  <input type="email" name="email" class="form-control" placeholder="Email Address" required>
                </div>
                <div class="col-md-12">
                  <input type="text" name="phone" class="form-control" placeholder="Phone Number" required>
                </div>
                <div class="col-md-12">
                  <input type="text" name="address" class="form-control" placeholder="Billing Address" required>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control" name="note" rows="4" placeholder="Additional Notes (Optional)"></textarea>
                </div>
              </div>
            </form>
          </div><!-- End Billing Details -->

          <div class="col-lg-6">
            <h3>Order Summary</h3>
            <div class="order-summary">
              <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  Course Name
                  <span class="fw-bold">$99.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  Tax (5%)
                  <span class="fw-bold">$4.95</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  <strong>Total</strong>
                  <strong>$103.95</strong>
                </li>
              </ul>
            </div>
            <div class="payment-method mt-4">
              <h3>Payment Method</h3>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" value="paypal" required>
                <label class="form-check-label">PayPal</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" value="stripe" required>
                <label class="form-check-label">Credit/Debit Card</label>
              </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 mt-4">Proceed to Payment</button>
          </div><!-- End Order Summary -->
        </div>
      </div>
    </section><!-- /Checkout Section -->

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elearning\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>