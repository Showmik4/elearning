

<?php $__env->startSection('title'); ?>
<?php echo e('Home Page'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('frontend_main.content'); ?>

<main class="main">

    <!-- Page Title -->
    <div class="page-title" data-aos="fade">
      <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>Courses</h1>
              <p class="mb-0"><?php echo @$setting->course_page_banner_text; ?></p>
            </div>
          </div>
        </div>
      </div>
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
            <li class="current">Courses</li>
          </ol>
        </div>
      </nav>
    </div><!-- End Page Title -->
    <!-- Courses Section -->
    <section id="courses" class="courses section">
      <div class="container">
        <div class="row">
          <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="course-item">
              <a href="<?php echo e(route('course_details', ['id' => $courses->id])); ?>">
              <img src="<?php echo e(url('public/frontend/assets/img/course-1.jpg')); ?>" class="img-fluid" alt="...">
              <div class="course-content">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <p class="category"><?php echo e($courses->category->name); ?></p>
                  <p class="price">$<?php echo e($courses->price); ?></p>
                </div>
                <h3><a href="course-details.html"><?php echo e($courses->title); ?></a></h3>
                <p class="description"><?php echo e($courses->short_details); ?></p>
                <div class="trainer d-flex justify-content-between align-items-center">
                  <div class="trainer-profile d-flex align-items-center">
                    <img src="<?php echo e(url($courses->trainer->image)); ?>" class="img-fluid" alt="">
                    <a href="" class="trainer-link"><?php echo e($courses->trainer->name); ?></a>
                  </div>
                  <div class="trainer-rank d-flex align-items-center">
                    <i class="bi bi-person user-icon"></i>&nbsp;50
                    &nbsp;&nbsp;
                    <i class="bi bi-heart heart-icon"></i>&nbsp;65
                  </div>
                </div>
              </div>
              </a>
            </div>
          </div> <!-- End Course Item-->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section><!-- /Courses Section -->
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elearning\resources\views/frontend/course.blade.php ENDPATH**/ ?>